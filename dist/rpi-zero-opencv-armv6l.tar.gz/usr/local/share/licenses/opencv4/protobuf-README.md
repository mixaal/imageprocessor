Project: Protocol Buffers - Google's data interchange format
Source code: https://github.com/google/protobuf
Version: 3.5.1
